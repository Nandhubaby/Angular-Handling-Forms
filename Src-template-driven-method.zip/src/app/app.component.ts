import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'form-td-assignment';
  submitted = false;
  subscriptions = ['Basic', 'Advanced', 'Pro'];
  selectedSubscription = 'Advanced';
  user = {
    email: '',
    password: '',
  };
  @ViewChild('form') signup!: NgForm;
  onSubmit() {
    this.submitted = true;
    console.log(this.signup.value);
    this.user.email = this.signup.value.email; //in the signup form accessing the value of the email
    this.user.password = this.signup.value.password;
    console.log('Email:', this.user.email);
    console.log('Password:', this.user.password);
  }
}
